<?php
require_once 'config/database.php';

if (isset($_SESSION['user_id'])) {
    header('Location: ' . ($_SESSION['role'] === 'admin' ? 'admin/dashboard.php' : 'dashboard.php'));
    exit;
}

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();

    $email    = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $error = 'Email, password rendum kudunga.';
    } else {
        $stmt = $conn->prepare('SELECT id, name, password, role FROM users WHERE email = ?');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        // password_verify compares the typed password with the stored hash
        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);               // stops session fixation
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['name']    = $user['name'];
            $_SESSION['role']    = $user['role'];

            header('Location: ' . ($user['role'] === 'admin' ? 'admin/dashboard.php' : 'dashboard.php'));
            exit;
        }
        $error = 'Email illa password thappu.';
    }
}

$pageTitle = 'Login';
$base = '';
include 'includes/header.php';
?>
<div class="auth-box">
  <h2>Welcome back 👋</h2>
  <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>

  <form method="post" id="loginForm" data-validate="login" novalidate>
    <?= csrf_field() ?>
    <label for="email">Email</label>
    <input type="email" id="email" name="email" value="<?= e($email) ?>" placeholder="you@college.edu">

    <label for="password">Password</label>
    <input type="password" id="password" name="password">

    <button class="btn btn-full" type="submit">Login</button>
  </form>
  <p class="center muted">Account illaya? <a href="register.php">Register</a></p>

  <div class="demo">
    <b>Demo logins</b><br>
    🛡️ Admin: admin@college.edu / Admin@123<br>
    🎓 Student: student@college.edu / Student@123
  </div>
</div>
<?php include 'includes/footer.php'; ?>
