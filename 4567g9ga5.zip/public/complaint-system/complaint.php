<?php
require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
if ($_SESSION['role'] !== 'student') { header('Location: admin/complaints.php'); exit; }

$id  = (int)($_GET['id'] ?? 0);
$uid = $_SESSION['user_id'];

// "AND user_id = ?" makes sure a student can open ONLY their own complaint
$stmt = $conn->prepare('SELECT id, category, subject, description, status, admin_response, created_at
                        FROM complaints WHERE id = ? AND user_id = ?');
$stmt->bind_param('ii', $id, $uid);
$stmt->execute();
$c = $stmt->get_result()->fetch_assoc();
$stmt->close();

$map = ['Pending' => 'b-pending', 'In Progress' => 'b-progress', 'Resolved' => 'b-resolved', 'Closed' => 'b-closed'];

$pageTitle = 'Complaint #' . $id;
$base = '';
include 'includes/header.php';
?>
<p><a href="dashboard.php">&larr; Back to my complaints</a></p>

<?php if (!$c): ?>
  <div class="card"><h3>Complaint kidaikala</h3><p class="muted">Indha complaint illa, illana adhu unga complaint illa.</p></div>
<?php else: ?>
  <div class="card">
    <div class="row-between">
      <h2><?= e($c['subject']) ?></h2>
      <span class="badge <?= $map[$c['status']] ?? 'b-pending' ?>"><?= e($c['status']) ?></span>
    </div>
    <p class="muted">#<?= (int)$c['id'] ?> &bull; <?= e($c['category']) ?> &bull; <?= e(date('d M Y, h:i A', strtotime($c['created_at']))) ?></p>

    <h4>Description</h4>
    <p class="pre"><?= e($c['description']) ?></p>

    <h4>Admin response</h4>
    <?php if ($c['admin_response']): ?>
      <div class="response pre"><?= e($c['admin_response']) ?></div>
    <?php else: ?>
      <p class="muted">Admin innum respond panala.</p>
    <?php endif; ?>
  </div>
<?php endif; ?>
<?php include 'includes/footer.php'; ?>
