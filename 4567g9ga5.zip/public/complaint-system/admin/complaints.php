<?php
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) { header('Location: ../login.php'); exit; }
if ($_SESSION['role'] !== 'admin') { header('Location: ../dashboard.php'); exit; }

$statuses = ['Pending', 'In Progress', 'Resolved', 'Closed'];
$filter   = in_array($_GET['status'] ?? '', $statuses, true) ? $_GET['status'] : '';

$sql = 'SELECT c.id, c.category, c.subject, c.description, c.status, c.admin_response, c.created_at,
               u.name AS student, u.email
        FROM complaints c JOIN users u ON u.id = c.user_id';
if ($filter !== '') {
    $stmt = $conn->prepare($sql . ' WHERE c.status = ? ORDER BY c.id DESC');
    $stmt->bind_param('s', $filter);
} else {
    $stmt = $conn->prepare($sql . ' ORDER BY c.id DESC');
}
$stmt->execute();
$complaints = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$map = ['Pending' => 'b-pending', 'In Progress' => 'b-progress', 'Resolved' => 'b-resolved', 'Closed' => 'b-closed'];

$pageTitle = 'All Complaints';
$base = '../';
include '../includes/header.php';
?>
<div class="row-between">
  <h1>All Complaints <small class="muted">(<?= count($complaints) ?>)</small></h1>
  <form method="get" class="filter">
    <select name="status" onchange="this.form.submit()">
      <option value="">All status</option>
      <?php foreach ($statuses as $s): ?>
        <option value="<?= e($s) ?>" <?= $filter === $s ? 'selected' : '' ?>><?= e($s) ?></option>
      <?php endforeach; ?>
    </select>
  </form>
</div>

<?php if (!$complaints): ?>
  <div class="card"><p class="muted">Complaints edhuvum illa.</p></div>
<?php endif; ?>

<?php foreach ($complaints as $c): ?>
<div class="card">
  <div class="row-between">
    <h3>#<?= (int)$c['id'] ?> &middot; <?= e($c['subject']) ?></h3>
    <span class="badge <?= $map[$c['status']] ?? 'b-pending' ?>"><?= e($c['status']) ?></span>
  </div>
  <p class="muted"><?= e($c['category']) ?> &bull; by <?= e($c['student']) ?> (<?= e($c['email']) ?>) &bull; <?= e(date('d M Y, h:i A', strtotime($c['created_at']))) ?></p>
  <p class="pre"><?= e($c['description']) ?></p>

  <!-- This form posts to update_status.php: change status + add response, OR delete -->
  <form method="post" action="update_status.php" class="admin-form">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
    <div class="admin-grid">
      <div>
        <label>Status</label>
        <select name="status">
          <?php foreach ($statuses as $s): ?>
            <option value="<?= e($s) ?>" <?= $c['status'] === $s ? 'selected' : '' ?>><?= e($s) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label>Response to student</label>
        <textarea name="admin_response" rows="3" placeholder="Student ku reply ezhudhunga..."><?= e($c['admin_response']) ?></textarea>
      </div>
    </div>
    <button class="btn btn-sm" type="submit" name="action" value="update">Save</button>
    <button class="btn btn-sm btn-danger" type="submit" name="action" value="delete"
            onclick="return confirm('Indha complaint-a permanent-a delete pannanuma?');">Delete</button>
  </form>
</div>
<?php endforeach; ?>
<?php include '../includes/footer.php'; ?>
