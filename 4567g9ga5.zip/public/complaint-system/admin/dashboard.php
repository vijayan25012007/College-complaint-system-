<?php
require_once '../config/database.php';

// ---- Role-based access: admin only ----
if (!isset($_SESSION['user_id'])) { header('Location: ../login.php'); exit; }
if ($_SESSION['role'] !== 'admin') { header('Location: ../dashboard.php'); exit; }

$counts = ['Pending' => 0, 'In Progress' => 0, 'Resolved' => 0, 'Closed' => 0];
foreach ($conn->query('SELECT status, COUNT(*) AS total FROM complaints GROUP BY status') as $row) {
    $counts[$row['status']] = (int)$row['total'];
}
$students = (int)$conn->query("SELECT COUNT(*) FROM users WHERE role = 'student'")->fetch_row()[0];

$recent = $conn->query('SELECT c.id, c.subject, c.category, c.status, c.created_at, u.name AS student
                        FROM complaints c JOIN users u ON u.id = c.user_id
                        ORDER BY c.id DESC LIMIT 5')->fetch_all(MYSQLI_ASSOC);

$map = ['Pending' => 'b-pending', 'In Progress' => 'b-progress', 'Resolved' => 'b-resolved', 'Closed' => 'b-closed'];

$pageTitle = 'Admin Dashboard';
$base = '../';
include '../includes/header.php';
?>
<h1>Admin Dashboard</h1>

<div class="stats">
  <div class="stat"><span>Total</span><b><?= array_sum($counts) ?></b></div>
  <?php foreach ($counts as $label => $n): ?>
    <div class="stat"><span><?= e($label) ?></span><b><?= $n ?></b></div>
  <?php endforeach; ?>
  <div class="stat"><span>Students</span><b><?= $students ?></b></div>
</div>

<div class="card">
  <div class="row-between"><h3>Latest complaints</h3><a href="complaints.php">View all &rarr;</a></div>
  <?php if (!$recent): ?>
    <p class="muted">Complaints edhuvum illa.</p>
  <?php else: ?>
  <div class="table-wrap">
    <table>
      <tr><th>#</th><th>Student</th><th>Subject</th><th>Category</th><th>Status</th><th>Date</th></tr>
      <?php foreach ($recent as $c): ?>
      <tr>
        <td><?= (int)$c['id'] ?></td>
        <td><?= e($c['student']) ?></td>
        <td><?= e($c['subject']) ?></td>
        <td><?= e($c['category']) ?></td>
        <td><span class="badge <?= $map[$c['status']] ?? 'b-pending' ?>"><?= e($c['status']) ?></span></td>
        <td><?= e(date('d M Y', strtotime($c['created_at']))) ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  </div>
  <?php endif; ?>
</div>
<?php include '../includes/footer.php'; ?>
