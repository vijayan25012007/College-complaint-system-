<?php
require_once '../config/database.php';

// Only admins, only POST
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') { header('Location: ../login.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: complaints.php'); exit; }
check_csrf();

$statuses = ['Pending', 'In Progress', 'Resolved', 'Closed'];
$id       = (int)($_POST['id'] ?? 0);
$action   = $_POST['action'] ?? '';

if ($id <= 0) {
    set_msg('Invalid complaint.', 'error');
    header('Location: complaints.php');
    exit;
}

if ($action === 'update') {
    $status   = $_POST['status'] ?? '';
    $response = trim($_POST['admin_response'] ?? '');
    $response = ($response === '') ? null : $response;      // empty -> NULL

    if (!in_array($status, $statuses, true)) {
        set_msg('Invalid status.', 'error');
    } else {
        // UPDATE (the U in CRUD)
        $stmt = $conn->prepare('UPDATE complaints SET status = ?, admin_response = ? WHERE id = ?');
        $stmt->bind_param('ssi', $status, $response, $id);
        $stmt->execute();
        $stmt->close();
        set_msg('Complaint #' . $id . ' update aagiduchu.');
    }
} elseif ($action === 'delete') {
    // DELETE (the D in CRUD)
    $stmt = $conn->prepare('DELETE FROM complaints WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();
    set_msg('Complaint #' . $id . ' delete aagiduchu.');
} else {
    set_msg('Unknown action.', 'error');
}

header('Location: complaints.php');
exit;
