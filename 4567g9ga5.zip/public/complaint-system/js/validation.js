/**
 * js/validation.js - client-side form validation.
 * NOTE: This only gives quick feedback. The REAL validation is in PHP (server side),
 * because anyone can disable JavaScript.
 *
 * Forms use  data-validate="login | register | complaint"
 */
(function () {
  function field(form, name) { return form.querySelector('[name="' + name + '"]'); }

  function clearErrors(form) {
    form.querySelectorAll('.field-error').forEach(function (n) { n.remove(); });
    form.querySelectorAll('.invalid').forEach(function (n) { n.classList.remove('invalid'); });
  }

  function showError(input, message) {
    input.classList.add('invalid');
    var span = document.createElement('span');
    span.className = 'field-error';
    span.textContent = message;
    input.insertAdjacentElement('afterend', span);
  }

  var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  var rules = {
    login: function (f) {
      var ok = true;
      if (!emailPattern.test(field(f, 'email').value.trim())) { showError(field(f, 'email'), 'Valid email kudunga.'); ok = false; }
      if (field(f, 'password').value === '') { showError(field(f, 'password'), 'Password kudunga.'); ok = false; }
      return ok;
    },
    register: function (f) {
      var ok = true;
      var name = field(f, 'name'), email = field(f, 'email'),
          pass = field(f, 'password'), conf = field(f, 'confirm_password');
      if (name.value.trim().length < 2) { showError(name, 'Name minimum 2 characters.'); ok = false; }
      if (!emailPattern.test(email.value.trim())) { showError(email, 'Valid email kudunga.'); ok = false; }
      if (pass.value.length < 6) { showError(pass, 'Password minimum 6 characters.'); ok = false; }
      if (conf.value !== pass.value || conf.value === '') { showError(conf, 'Rendu password-um match aaganum.'); ok = false; }
      return ok;
    },
    complaint: function (f) {
      var ok = true;
      var cat = field(f, 'category'), sub = field(f, 'subject'), desc = field(f, 'description');
      if (cat.value === '') { showError(cat, 'Category select pannunga.'); ok = false; }
      if (sub.value.trim().length < 5) { showError(sub, 'Subject minimum 5 characters.'); ok = false; }
      if (desc.value.trim().length < 10) { showError(desc, 'Description minimum 10 characters.'); ok = false; }
      return ok;
    }
  };

  document.querySelectorAll('form[data-validate]').forEach(function (form) {
    form.addEventListener('submit', function (event) {
      clearErrors(form);
      var check = rules[form.getAttribute('data-validate')];
      if (check && !check(form)) { event.preventDefault(); }
    });
  });
})();
