# College Complaint System (PHP + MySQL)

Students complaints submit pannuvanga, admin status maathi response kudupanga.

## Setup (XAMPP - Windows)
1. XAMPP-la **Apache** and **MySQL** start pannunga.
2. Indha `complaint-system` folder-a `C:\xampp\htdocs\` kulla copy pannunga.
3. `http://localhost/phpmyadmin` -> **Import** -> `database.sql` select -> **Go**
   (database `college_complaints` + tables `users`, `complaints` create aagum).
4. Open `http://localhost/complaint-system/`

## Setup (Linux / ByteXL terminal)
```
mysql -u <user> -p < database.sql        # or import via phpMyAdmin
DB_HOST=... DB_PORT=... DB_USER=... DB_PASS=... DB_NAME=... php -S 0.0.0.0:8080 -t .
```
(`config/database.php` la values direct-a-um maathalaam.)
Hosting-la CREATE DATABASE permission illana, `database.sql` la first rendu lines-a delete pannunga.

## Demo logins
| Role    | Email               | Password    |
|---------|---------------------|-------------|
| Admin   | admin@college.edu   | Admin@123   |
| Student | student@college.edu | Student@123 |

## Folder structure
```
index.php login.php register.php logout.php
dashboard.php submit_complaint.php complaint.php      (student)
admin/dashboard.php complaints.php update_status.php  (admin)
config/database.php   session + MySQL connection + helpers
includes/header.php footer.php
css/style.css   js/validation.js   database.sql
```

## Database
- `users(id, name, email, password, role, created_at)`
- `complaints(id, user_id, category, subject, description, status, admin_response, created_at)`

## Concepts (viva)
- **Forms + POST**: register, login, submit, admin update
- **Sessions**: `$_SESSION['user_id' | 'name' | 'role']`, `session_regenerate_id` after login
- **Password hashing**: `password_hash()` / `password_verify()`
- **Prepared statements**: `prepare()` + `bind_param()` -> SQL injection prevention
- **CRUD**: Create (register/submit), Read (dashboards), Update (status/response), Delete (admin)
- **Role-based pages**: student pages block admin, admin pages block students
- **Ownership check**: `WHERE id = ? AND user_id = ?` in complaint.php
- **JS validation** (validation.js) + **server validation** (PHP) - server is the real check
- **XSS**: `e()` = htmlspecialchars on all output; **CSRF** token on all POST forms
