<?php
require_once 'config/database.php';

$_SESSION = [];                    // clear all session data
session_destroy();                 // destroy the session on the server
session_start();                   // new session just to show the flash message
set_msg('Logout aagiteenga.');
header('Location: login.php');
exit;
