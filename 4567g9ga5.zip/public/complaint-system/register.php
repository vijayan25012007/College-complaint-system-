<?php
require_once 'config/database.php';

if (isset($_SESSION['user_id'])) { header('Location: dashboard.php'); exit; }

$errors = [];
$name = $email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();

    $name     = trim($_POST['name'] ?? '');
    $email    = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    // ---- Server-side validation (JS validation can be bypassed, so this is the real check) ----
    if (strlen($name) < 2 || strlen($name) > 100)        $errors[] = 'Name 2 to 100 characters irukanum.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))      $errors[] = 'Valid email kudunga.';
    if (strlen($password) < 6)                           $errors[] = 'Password minimum 6 characters irukanum.';
    if ($password !== $confirm)                          $errors[] = 'Rendu password-um match aagala.';

    if (!$errors) {
        // Is the email already used?  (prepared statement = safe from SQL injection)
        $stmt = $conn->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $exists = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($exists) {
            $errors[] = 'Indha email already register aagiduchu.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);   // never store plain passwords
            $role = 'student';                                    // public form can only create students
            $stmt = $conn->prepare('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)');
            $stmt->bind_param('ssss', $name, $email, $hash, $role);
            $stmt->execute();
            $stmt->close();

            set_msg('Registration success! Ippo login pannunga.');
            header('Location: login.php');
            exit;
        }
    }
}

$pageTitle = 'Register';
$base = '';
include 'includes/header.php';
?>
<div class="auth-box">
  <h2>Create student account</h2>
  <?php foreach ($errors as $er): ?><div class="alert alert-error"><?= e($er) ?></div><?php endforeach; ?>

  <form method="post" id="registerForm" data-validate="register" novalidate>
    <?= csrf_field() ?>
    <label for="name">Full name</label>
    <input type="text" id="name" name="name" value="<?= e($name) ?>">

    <label for="email">Email</label>
    <input type="email" id="email" name="email" value="<?= e($email) ?>" placeholder="you@college.edu">

    <label for="password">Password</label>
    <input type="password" id="password" name="password" placeholder="Minimum 6 characters">

    <label for="confirm_password">Confirm password</label>
    <input type="password" id="confirm_password" name="confirm_password">

    <button class="btn btn-full" type="submit">Register</button>
  </form>
  <p class="center muted">Already account irukka? <a href="login.php">Login</a></p>
</div>
<?php include 'includes/footer.php'; ?>
