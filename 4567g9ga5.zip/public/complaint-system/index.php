<?php
require_once 'config/database.php';

// Already logged in? Send to the right dashboard.
if (isset($_SESSION['user_id'])) {
    header('Location: ' . ($_SESSION['role'] === 'admin' ? 'admin/dashboard.php' : 'dashboard.php'));
    exit;
}

$pageTitle = 'Home';
$base = '';
include 'includes/header.php';
?>
<section class="hero">
  <h1>Got a problem on campus?<br>Tell us. We'll fix it.</h1>
  <p>Students submit complaints to the college administration and track the status online.</p>
  <p>
    <a class="btn btn-lg" href="register.php">Register as Student</a>
    <a class="btn btn-lg btn-light" href="login.php">Login</a>
  </p>
</section>
<section class="grid3">
  <div class="card"><h3>✍️ Submit</h3><p>Hostel, canteen, academics, transport... anything. Submit in a minute.</p></div>
  <div class="card"><h3>🔎 Track</h3><p>Check whether your complaint is Pending, In Progress, Resolved or Closed.</p></div>
  <div class="card"><h3>✅ Resolved</h3><p>Admin reads each complaint and replies with a response.</p></div>
</section>
<?php include 'includes/footer.php'; ?>
