-- =============================================================
-- College Complaint System
-- Import this file in phpMyAdmin (Import tab) or: mysql -u root < database.sql
-- NOTE: Hosting-la CREATE DATABASE permission illana, rendu lines
--       (CREATE DATABASE / USE) a delete pannitu, unga database-a select panni import pannunga.
-- =============================================================
CREATE DATABASE IF NOT EXISTS college_complaints
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE college_complaints;

-- ---------------- users ----------------
CREATE TABLE IF NOT EXISTS users (
  id         INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(100) NOT NULL,
  email      VARCHAR(150) NOT NULL UNIQUE,
  password   VARCHAR(255) NOT NULL,                       -- bcrypt hash from password_hash()
  role       ENUM('student','admin') NOT NULL DEFAULT 'student',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------- complaints ----------------
CREATE TABLE IF NOT EXISTS complaints (
  id             INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id        INT NOT NULL,
  category       VARCHAR(100) NOT NULL,
  subject        VARCHAR(200) NOT NULL,
  description    TEXT NOT NULL,
  status         ENUM('Pending','In Progress','Resolved','Closed') NOT NULL DEFAULT 'Pending',
  admin_response TEXT NULL,
  created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_complaints_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------- demo accounts ----------------
-- Admin   : admin@college.edu   / Admin@123
-- Student : student@college.edu / Student@123
INSERT INTO users (name, email, password, role) VALUES
 ('Administrator', 'admin@college.edu',   '$2y$12$sAkv/Am5KWAQAEN9rfS5ye4BrzORI5VbExZ.ruQg3gnwjZ09nalOO', 'admin'),
 ('Demo Student',  'student@college.edu', '$2y$12$11PX51HAYOJw36t9ySTRQ.tQklql0YPcKadW3iQjm56avhTAY4MGC', 'student')
ON DUPLICATE KEY UPDATE email = email;
