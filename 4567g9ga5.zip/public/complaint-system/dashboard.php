<?php
require_once 'config/database.php';

// ---- Role-based access: students only ----
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
if ($_SESSION['role'] !== 'student') { header('Location: admin/dashboard.php'); exit; }

$uid = $_SESSION['user_id'];

// Count my complaints by status
$counts = ['Pending' => 0, 'In Progress' => 0, 'Resolved' => 0, 'Closed' => 0];
$stmt = $conn->prepare('SELECT status, COUNT(*) AS total FROM complaints WHERE user_id = ? GROUP BY status');
$stmt->bind_param('i', $uid);
$stmt->execute();
foreach ($stmt->get_result() as $row) { $counts[$row['status']] = (int)$row['total']; }
$stmt->close();

// All my complaints (newest first)
$stmt = $conn->prepare('SELECT id, category, subject, status, created_at FROM complaints WHERE user_id = ? ORDER BY id DESC');
$stmt->bind_param('i', $uid);
$stmt->execute();
$complaints = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

function status_class($s) {
    return ['Pending' => 'b-pending', 'In Progress' => 'b-progress', 'Resolved' => 'b-resolved', 'Closed' => 'b-closed'][$s] ?? 'b-pending';
}

$pageTitle = 'My Complaints';
$base = '';
include 'includes/header.php';
?>
<h1>Hi, <?= e($_SESSION['name']) ?> 👋</h1>

<div class="stats">
  <div class="stat"><span>Total</span><b><?= array_sum($counts) ?></b></div>
  <?php foreach ($counts as $label => $n): ?>
    <div class="stat"><span><?= e($label) ?></span><b><?= $n ?></b></div>
  <?php endforeach; ?>
</div>

<div class="card">
  <div class="row-between">
    <h3>My complaints</h3>
    <a class="btn btn-sm" href="submit_complaint.php">+ New Complaint</a>
  </div>

  <?php if (!$complaints): ?>
    <p class="muted">Innum complaint submit panala.</p>
  <?php else: ?>
  <div class="table-wrap">
    <table>
      <tr><th>#</th><th>Subject</th><th>Category</th><th>Status</th><th>Submitted</th></tr>
      <?php foreach ($complaints as $c): ?>
      <tr>
        <td><?= (int)$c['id'] ?></td>
        <td><a href="complaint.php?id=<?= (int)$c['id'] ?>"><?= e($c['subject']) ?></a></td>
        <td><?= e($c['category']) ?></td>
        <td><span class="badge <?= status_class($c['status']) ?>"><?= e($c['status']) ?></span></td>
        <td><?= e(date('d M Y, h:i A', strtotime($c['created_at']))) ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  </div>
  <?php endif; ?>
</div>
<?php include 'includes/footer.php'; ?>
