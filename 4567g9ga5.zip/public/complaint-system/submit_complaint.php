<?php
require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
if ($_SESSION['role'] !== 'student') { header('Location: admin/dashboard.php'); exit; }

$categories = ['Academics', 'Hostel', 'Canteen', 'Transport', 'Library', 'Infrastructure', 'Fees', 'Other'];
$errors = [];
$category = $subject = $description = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();

    $category    = $_POST['category'] ?? '';
    $subject     = trim($_POST['subject'] ?? '');
    $description = trim($_POST['description'] ?? '');

    if (!in_array($category, $categories, true))        $errors[] = 'Category select pannunga.';
    if (strlen($subject) < 5 || strlen($subject) > 200) $errors[] = 'Subject 5 to 200 characters irukanum.';
    if (strlen($description) < 10)                      $errors[] = 'Description konjam detail-a ezhudhunga (min 10 characters).';

    if (!$errors) {
        $uid = $_SESSION['user_id'];
        // status = 'Pending' and created_at are filled by the database defaults
        $stmt = $conn->prepare('INSERT INTO complaints (user_id, category, subject, description) VALUES (?, ?, ?, ?)');
        $stmt->bind_param('isss', $uid, $category, $subject, $description);
        $stmt->execute();
        $newId = $conn->insert_id;
        $stmt->close();

        set_msg('Complaint submit aagiduchu! (ID: ' . $newId . ')');
        header('Location: complaint.php?id=' . $newId);
        exit;
    }
}

$pageTitle = 'New Complaint';
$base = '';
include 'includes/header.php';
?>
<h1>Submit a complaint</h1>
<div class="card narrow">
  <?php foreach ($errors as $er): ?><div class="alert alert-error"><?= e($er) ?></div><?php endforeach; ?>

  <form method="post" id="complaintForm" data-validate="complaint" novalidate>
    <?= csrf_field() ?>
    <label for="category">Category</label>
    <select id="category" name="category">
      <option value="">-- Select category --</option>
      <?php foreach ($categories as $c): ?>
        <option value="<?= e($c) ?>" <?= $category === $c ? 'selected' : '' ?>><?= e($c) ?></option>
      <?php endforeach; ?>
    </select>

    <label for="subject">Subject</label>
    <input type="text" id="subject" name="subject" maxlength="200" value="<?= e($subject) ?>">

    <label for="description">Description</label>
    <textarea id="description" name="description" rows="6"><?= e($description) ?></textarea>

    <button class="btn" type="submit">Submit Complaint</button>
  </form>
</div>
<?php include 'includes/footer.php'; ?>
