<?php
// Expects (set BEFORE including): $pageTitle (string), $base ('' for root pages, '../' for admin pages)
$base      = $base ?? '';
$pageTitle = $pageTitle ?? 'College Complaint System';
$role      = $_SESSION['role'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($pageTitle) ?> | Complaint System</title>
  <link rel="stylesheet" href="<?= e($base) ?>css/style.css">
</head>
<body>
<header class="navbar">
  <div class="container nav-inner">
    <a class="logo" href="<?= e($base) ?>index.php">📢 Complaint System</a>
    <nav>
      <?php if ($role === 'admin'): ?>
        <a href="<?= e($base) ?>admin/dashboard.php">Dashboard</a>
        <a href="<?= e($base) ?>admin/complaints.php">All Complaints</a>
        <span class="who">👤 <?= e($_SESSION['name']) ?> (Admin)</span>
        <a class="btn btn-sm btn-light" href="<?= e($base) ?>logout.php">Logout</a>
      <?php elseif ($role === 'student'): ?>
        <a href="<?= e($base) ?>dashboard.php">My Complaints</a>
        <a href="<?= e($base) ?>submit_complaint.php">New Complaint</a>
        <span class="who">👤 <?= e($_SESSION['name']) ?></span>
        <a class="btn btn-sm btn-light" href="<?= e($base) ?>logout.php">Logout</a>
      <?php else: ?>
        <a href="<?= e($base) ?>login.php">Login</a>
        <a class="btn btn-sm" href="<?= e($base) ?>register.php">Register</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main class="container">
<?php if (!empty($_SESSION['msg'])): ?>
  <div class="alert alert-<?= e($_SESSION['msg']['type']) ?>"><?= e($_SESSION['msg']['text']) ?></div>
  <?php unset($_SESSION['msg']); ?>
<?php endif; ?>
