</main>
<footer class="footer">
  <div class="container">&copy; <?= date('Y') ?> College Complaint System &middot; PHP + MySQL</div>
</footer>
<script src="<?= e($base ?? '') ?>js/validation.js"></script>
</body>
</html>
