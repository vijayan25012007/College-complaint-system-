<?php
/**
 * config/database.php
 * - Starts the session (every page includes this file first)
 * - Connects to MySQL using mysqli
 * - Small helper functions used everywhere
 *
 * XAMPP default: host=localhost, user=root, password=(empty)
 * Vera host na keela values maathunga (or environment variables set pannunga).
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$DB_HOST = getenv('DB_HOST') ?: 'db01.dbhost.dev';
$DB_PORT = (int)(getenv('DB_PORT') ?: 5051);
$DB_USER = getenv('DB_USER') ?: 'user_4567hjv9c';
$DB_PASS = getenv('DB_PASS') !== false ? getenv('p4567hjv9c') : '';
$DB_NAME = getenv('DB_NAME') ?: 'db_4567hjv9c';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);   // errors -> exceptions
try {
    $conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME, $DB_PORT);
    $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $ex) {
    http_response_code(500);
    exit('<h2>Database connection failed</h2><p>' . htmlspecialchars($ex->getMessage()) .
         '</p><p>config/database.php check pannunga, database.sql import pannirukkingala nu paarunga.</p>');
}

/** Escape output (prevents XSS). Use it on EVERY value printed in HTML. */
function e($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

/** CSRF protection for POST forms */
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}
function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}
function check_csrf(): void {
    $sent = $_POST['csrf'] ?? '';
    if (empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $sent)) {
        http_response_code(400);
        exit('Invalid request (CSRF). Page-a refresh panni marupadi try pannunga.');
    }
}

/** Flash message shown once on the next page */
function set_msg(string $text, string $type = 'success'): void {
    $_SESSION['msg'] = ['text' => $text, 'type' => $type];
}
